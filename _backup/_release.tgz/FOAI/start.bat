@echo off
REM Chennai Relief Control - starts the API (port 8000) and the web app (port 5173).
setlocal
cd /d "%~dp0"

if not exist .venv (
  echo Creating Python environment...
  python -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -q -r backend\requirements.txt

if not exist frontend\node_modules (
  echo Installing web app packages...
  pushd frontend
  call npm install
  popd
)

start "Chennai Relief - API" cmd /k "cd /d %~dp0 && call .venv\Scripts\activate.bat && python -m uvicorn backend.main:app --port 8000"
start "Chennai Relief - Web" cmd /k "cd /d %~dp0frontend && npm run dev"

echo.
echo Open http://localhost:5173 in your browser.
echo The first start downloads Chennai's real road network (about 1-2 minutes, needs internet).
endlocal
