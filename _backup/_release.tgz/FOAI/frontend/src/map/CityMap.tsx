import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import maplibregl, { type GeoJSONSource, type Map as MLMap } from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { Box, Home, Layers, TriangleAlert } from 'lucide-react';
import { api } from '../api';
import { useStore } from '../store';
import type { FC, Hotspot, LayerToggles, Selection } from '../types';
import { pointInGeometry, polygonRings, type LngLat } from '../lib/geo';
import { CLICKABLE, SRC, buildStyle } from './style';
import { depotsData, floodsData, needsData, selectionData, zoneLabelsData, zonesData } from './data';
import { EMPTY_SCENE, depotMetrics, drawScene, makeProjector, type DepotDraw, type Scene } from './overlay';

export interface CityMapFocus {
  nonce: number;
  bbox?: [LngLat, LngLat];
  center?: LngLat;
  zoom?: number;
  pitch?: number;
}
export interface Pad { top: number; right: number; bottom: number; left: number }

interface Props {
  layers: LayerToggles;
  riskMode?: 'full' | 'faint';
  selection: Selection | null;
  onSelect: (s: Selection | null) => void;
  onRoadPick?: (lng: number, lat: number) => void;
  focus?: CityMapFocus | null;
  scene?: Partial<Omit<Scene, 'rings' | 'theme'>>;
  padding?: Pad;
  children?: ReactNode;
}

const MAX_BOUNDS: [[number, number], [number, number]] = [[79.93, 12.74], [80.43, 13.36]];
const ATTRIBUTION =
  '<a href="https://openfreemap.org" target="_blank" rel="noreferrer">OpenFreeMap</a> © <a href="https://www.openmaptiles.org/" target="_blank" rel="noreferrer">OpenMapTiles</a> data from <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">OpenStreetMap</a> · zones: Datameet / Transparent Chennai (CC BY-SA 2.5 IN)';

const GROUPS: Record<keyof LayerToggles, string[]> = {
  risk: ['zones-fill', 'zones-line', 'zones-3d'],
  floods: ['floods-fill', 'floods-line'],
  depots: ['depot-labels'],
  needs: ['needs', 'needs-halo', 'needs-labels'],
  roads: ['road-state-slow', 'road-state-blocked'],
};

export default function CityMap({ layers, riskMode = 'full', selection, onSelect, onRoadPick, focus, scene, padding, children }: Props) {
  const { zones, outline, bounds, state, theme } = useStore();
  const host = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MLMap | null>(null);
  const overlay = useRef<HTMLCanvasElement | null>(null);
  const [ready, setReady] = useState(false);
  const [tilesFailed, setTilesFailed] = useState(false);
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [roadFC, setRoadFC] = useState<FC | null>(null);
  const [flat, setFlat] = useState(false);
  const home = useRef<{ center: [number, number]; zoom: number } | null>(null);
  const hoverId = useRef<string | null>(null);
  const selZone = useRef<string | null>(null);

  const rings = useMemo(() => (outline ? polygonRings(outline.geometry) : []), [outline]);
  const sceneRef = useRef<Scene>({ ...EMPTY_SCENE });
  const depotDraw = useMemo<DepotDraw[]>(() => (!layers.depots ? [] : (state?.warehouses ?? []).map((d) => ({
    id: d.id, pos: [d.lng, d.lat] as LngLat, scale: d.scale, active: d.active, selected: selection?.kind === 'depot' && selection.id === d.id,
  }))), [state, layers.depots, selection]);
  sceneRef.current = { ...EMPTY_SCENE, ...scene, depots: depotDraw, rings, theme };

  const live = useRef({ zones, state, hotspots, roadFC, layers, riskMode, selection, outline, onSelect, onRoadPick, theme });
  live.current = { zones, state, hotspots, roadFC, layers, riskMode, selection, outline, onSelect, onRoadPick, theme };

  useEffect(() => { api.hotspots().then(setHotspots).catch(() => undefined); }, []);
  const netVersion = state?.network.version;
  useEffect(() => {
    api.overlay().then(setRoadFC).catch(() => setRoadFC(null));
  }, [netVersion]);

  // ------------------------------------------------------------------ push data to the style
  const sync = useCallback(() => {
    const map = mapRef.current;
    const L = live.current;
    if (!map || !map.getSource(SRC.zones) || !L.zones) return;
    const set = (id: string, data: GeoJSON.FeatureCollection) => (map.getSource(id) as GeoJSONSource | undefined)?.setData(data);
    set(SRC.zones, zonesData(L.zones, L.state));
    set(SRC.zoneLabels, zoneLabelsData(L.zones));
    const areas = L.state?.affected_areas ?? [];
    const depots = L.state?.warehouses ?? [];
    set(SRC.floods, floodsData(areas, L.hotspots));
    set(SRC.depots, depotsData(depots));
    set(SRC.needs, needsData(areas));
    set(SRC.roadState, L.roadFC ?? { type: 'FeatureCollection', features: [] });
    const sel = selectionData(L.selection, depots, areas);
    set(SRC.selection, sel.ring);
    set(SRC.selectionLine, sel.line);

    // visibility
    (Object.keys(GROUPS) as (keyof LayerToggles)[]).forEach((k) => {
      GROUPS[k].forEach((id) => {
        if (!map.getLayer(id)) return;
        let on = L.layers[k];
        if (k === 'risk' && id === 'zones-3d') on = on && L.riskMode === 'full';
        map.setLayoutProperty(id, 'visibility', on ? 'visible' : 'none');
      });
    });
    if (map.getLayer('zones-fill')) {
      map.setPaintProperty('zones-fill', 'fill-opacity', L.riskMode === 'faint'
        ? ['interpolate', ['linear'], ['zoom'], 9, 0.22, 14, 0.1]
        : ['interpolate', ['linear'], ['zoom'], 9, 0.5, 12.5, 0.38, 14, 0.2]);
    }

    // selected zone outline via feature-state
    const wantZone = L.selection?.kind === 'zone' ? L.selection.id : null;
    if (selZone.current && selZone.current !== wantZone) map.setFeatureState({ source: SRC.zones, id: selZone.current }, { selected: false });
    if (wantZone) map.setFeatureState({ source: SRC.zones, id: wantZone }, { selected: true });
    selZone.current = wantZone;
  }, []);

  // ------------------------------------------------------------------ create map once
  useEffect(() => {
    if (!host.current || !bounds || mapRef.current) return;
    const map = new maplibregl.Map({
      container: host.current,
      style: buildStyle(live.current.theme),
      center: [80.19, 13.04],
      zoom: 10.4,
      pitch: 50,
      bearing: -8,
      minZoom: 9.2,
      maxZoom: 17.8,
      maxPitch: 72,
      maxBounds: MAX_BOUNDS,
      attributionControl: { compact: true, customAttribution: ATTRIBUTION },
      dragRotate: true,
      fadeDuration: 150,
    });
    mapRef.current = map;
    if (import.meta.env.DEV) (window as unknown as { __crcMap?: MLMap }).__crcMap = map;
    map.addControl(new maplibregl.NavigationControl({ visualizePitch: true, showZoom: true }), 'bottom-right');

    // overlay canvas: hides everything outside Chennai and draws routes and trucks above the 3D buildings
    const cv = document.createElement('canvas');
    cv.className = 'map-overlay';
    map.getCanvasContainer().appendChild(cv);
    overlay.current = cv;
    const ctx = cv.getContext('2d');
    const draw = () => {
      if (!ctx) return;
      const r = map.getContainer().getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const w = Math.round(r.width);
      const h = Math.round(r.height);
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
        cv.width = Math.round(w * dpr);
        cv.height = Math.round(h * dpr);
        cv.style.width = `${w}px`;
        cv.style.height = `${h}px`;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      drawScene(ctx, map, sceneRef.current, w, h);
    };
    map.on('render', draw);
    const ro = new ResizeObserver(() => { map.resize(); });
    ro.observe(host.current);

    map.on('style.load', () => { setReady(true); sync(); });

    map.on('error', (e) => {
      const err = e as unknown as { sourceId?: string; error?: { status?: number; message?: string } };
      if (err.sourceId === SRC.omt || /Failed to fetch|NetworkError|AJAX/i.test(err.error?.message ?? '')) setTilesFailed(true);
    });
    map.on('sourcedata', (e) => {
      if (e.sourceId === SRC.omt && e.isSourceLoaded) setTilesFailed(false);
    });

    // ---- interaction
    const existing = (ids: readonly string[]) => ids.filter((id) => map.getLayer(id));
    const hitDepot = (x: number, y: number): string | null => {
      const L = live.current;
      if (!L.layers.depots) return null;
      const pj = makeProjector(map);
      for (const d of L.state?.warehouses ?? []) {
        const g = pj.point([d.lng, d.lat]);
        if (!g) continue;
        const dm = depotMetrics(d.scale, map.getZoom());
        const hy = g.y - dm.stem - dm.size / 2;
        if (Math.hypot(x - g.x, y - hy) <= Math.max(dm.size * 0.8, 9) || Math.hypot(x - g.x, y - g.y) <= 9) return d.id;
      }
      return null;
    };
    map.on('click', (e) => {
      const L = live.current;
      const pt = [e.lngLat.lng, e.lngLat.lat] as LngLat;
      if (L.outline && !pointInGeometry(pt, L.outline.geometry)) { L.onSelect(null); return; }
      const depot = hitDepot(e.point.x, e.point.y);
      if (depot) { L.onSelect({ kind: 'depot', id: depot }); return; }
      const marks = map.queryRenderedFeatures(e.point, { layers: existing(['needs']) });
      if (marks.length) { L.onSelect({ kind: 'area', id: String(marks[0].properties?.id) }); return; }
      if (L.layers.roads && L.onRoadPick && map.getZoom() >= 11.8) { L.onRoadPick(pt[0], pt[1]); return; }
      const zf = map.queryRenderedFeatures(e.point, { layers: existing(['zones-3d', 'zones-fill']) });
      if (zf.length) L.onSelect({ kind: 'zone', id: String(zf[0].properties?.id) });
      else L.onSelect(null);
    });
    map.on('mousemove', (e) => {
      const L = live.current;
      const marks = hitDepot(e.point.x, e.point.y) ? [1] : map.queryRenderedFeatures(e.point, { layers: existing(['needs']) });
      const zf = marks.length ? [] : map.queryRenderedFeatures(e.point, { layers: existing(['zones-3d', 'zones-fill']) });
      map.getCanvas().style.cursor = marks.length || zf.length || (L.layers.roads && map.getZoom() >= 11.8) ? 'pointer' : '';
      const id = zf.length ? String(zf[0].properties?.id) : null;
      if (id !== hoverId.current) {
        if (hoverId.current) map.setFeatureState({ source: SRC.zones, id: hoverId.current }, { hover: false });
        if (id) map.setFeatureState({ source: SRC.zones, id }, { hover: true });
        hoverId.current = id;
      }
    });
    map.on('mouseout', () => {
      if (hoverId.current) map.setFeatureState({ source: SRC.zones, id: hoverId.current }, { hover: false });
      hoverId.current = null;
    });

    return () => { ro.disconnect(); map.remove(); mapRef.current = null; overlay.current = null; setReady(false); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bounds]);

  // fit the whole city once the map exists
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready || !bounds || home.current) return;
    map.fitBounds(bounds, { padding: { top: 40, bottom: 40, left: 30, right: 30 }, pitch: 50, bearing: -8, duration: 0, maxZoom: 11.6 });
    home.current = { center: map.getCenter().toArray() as [number, number], zoom: map.getZoom() };
  }, [ready, bounds]);

  // theme change -> new style
  const firstTheme = useRef(theme);
  useEffect(() => {
    const map = mapRef.current;
    if (!map || theme === firstTheme.current) return;
    firstTheme.current = theme;
    map.setStyle(buildStyle(theme));
  }, [theme]);

  // data / selection / layer changes
  useEffect(() => { sync(); }, [sync, ready, zones, state, hotspots, roadFC, layers, riskMode, selection]);
  // scene changes repaint the overlay
  useEffect(() => { mapRef.current?.triggerRepaint(); }, [scene, rings, theme]);

  // camera requests
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !focus) return;
    const pad = padding ?? { top: 60, right: 60, bottom: 60, left: 60 };
    if (focus.bbox) map.fitBounds(focus.bbox, { padding: pad, duration: 900, maxZoom: 13.1, pitch: flat ? 0 : focus.pitch ?? 50 });
    else if (focus.center) map.easeTo({ center: focus.center, zoom: focus.zoom ?? 14, duration: 900, pitch: flat ? 0 : focus.pitch ?? 55, padding: pad });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focus?.nonce]);

  const resetView = () => {
    const map = mapRef.current;
    if (!map || !bounds) return;
    map.fitBounds(bounds, { padding: { top: 40, bottom: 40, left: 30, right: 30 }, pitch: flat ? 0 : 50, bearing: flat ? 0 : -8, duration: 900, maxZoom: 11.6 });
  };
  const toggleFlat = () => {
    const map = mapRef.current;
    if (!map) return;
    const next = !flat;
    setFlat(next);
    map.easeTo({ pitch: next ? 0 : 52, bearing: next ? 0 : map.getBearing(), duration: 700 });
  };

  return (
    <div className="citymap">
      <div ref={host} className="citymap__gl" />
      <div className="citymap__tools" role="toolbar" aria-label="Map view">
        <button className="maptool" onClick={toggleFlat} aria-pressed={flat} title={flat ? 'Tilt to 3D view' : 'Flatten to top-down view'}>
          {flat ? <Box size={16} /> : <Layers size={16} />}<span>{flat ? '3D' : '2D'}</span>
        </button>
        <button className="maptool" onClick={resetView} title="Show all of Chennai"><Home size={16} /><span>All Chennai</span></button>
      </div>
      {tilesFailed && (
        <div className="citymap__warn" role="status">
          <TriangleAlert size={16} />
          <span>Street map tiles could not load. Check your internet connection. Risk, depots and routes still work.</span>
        </div>
      )}
      <div className="citymap__ui">{children}</div>
    </div>
  );
}
