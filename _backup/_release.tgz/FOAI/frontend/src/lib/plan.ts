import type { Plan, TruckPlan } from '../types';
import { pathLengths, pointAlong, type LngLat } from './geo';

export interface RouteIndex { truck: TruckPlan; path: LngLat[]; cum: number[] }

export function indexPlan(plan: Plan | null): RouteIndex[] {
  if (!plan) return [];
  return plan.truck_plans
    .filter((t) => t.route_lnglat.length > 1)
    .map((t) => {
      const path = t.route_lnglat as LngLat[];
      return { truck: t, path, cum: pathLengths(path).cum };
    });
}

/** Where a truck is `t` hours after dispatch, or null once it is back at the depot. */
export function truckPosition(r: RouteIndex, t: number): LngLat | null {
  const legs = r.truck.legs;
  if (!legs.length) return null;
  if (t <= legs[0].depart_h) return r.path[0];
  for (let i = 0; i < legs.length; i++) {
    const L = legs[i];
    if (t >= L.depart_h && t <= L.arrive_h) {
      const span = L.arrive_h - L.depart_h;
      return pointAlong(r.path, r.cum, Math.min(L.i0, r.path.length - 1), Math.min(L.i1, r.path.length - 1), span > 0 ? (t - L.depart_h) / span : 1);
    }
    const next = legs[i + 1];
    if (next && t > L.arrive_h && t < next.depart_h) return r.path[Math.min(L.i1, r.path.length - 1)];
  }
  return null;
}

export function addHours(iso: string | null | undefined, hours: number): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  return new Date(d.getTime() + hours * 3600_000).toISOString();
}
