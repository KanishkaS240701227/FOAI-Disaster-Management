import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Pause, Play, RotateCcw, Truck as TruckIcon, ListChecks, Sparkles, TriangleAlert } from 'lucide-react';
import { api } from '../api';
import { useStore } from '../store';
import CityMap, { type CityMapFocus } from '../map/CityMap';
import RoadDataNotice from '../components/RoadDataNotice';
import TruckTimeline from '../components/TruckTimeline';
import type { AStarResult, LayerToggles, Plan, Selection } from '../types';
import { fmt, fmtClock, fmtDuration, fmtPeople, sumBundle } from '../lib/format';
import { addHours, indexPlan, truckPosition } from '../lib/plan';
import { bboxOf, type LngLat } from '../lib/geo';
import type { Scene } from '../map/overlay';

type Tab = 'trucks' | 'deliveries' | 'explain';
interface ExplainState { result: AStarResult; upto: number; playing: boolean }
const EFFORT = {
  quick: { label: 'Quick', generations: 100, population_size: 60 },
  standard: { label: 'Standard', generations: 250, population_size: 100 },
  thorough: { label: 'Thorough', generations: 600, population_size: 160 },
} as const;

const DISPATCH_LAYERS: LayerToggles = { risk: true, floods: true, depots: true, needs: true, roads: true };

export default function DispatchPage() {
  const { state, plan, selectedTruck, selectTruck } = useStore();
  const [tab, setTab] = useState<Tab>('trucks');
  const [explain, setExplain] = useState<ExplainState | null>(null);
  const [focus, setFocus] = useState<CityMapFocus | null>(null);

  const idx = useMemo(() => indexPlan(plan), [plan]);

  const chooseTruck = useCallback((id: string | null) => {
    selectTruck(id);
    if (!id) return;
    const r = idx.find((x) => x.truck.truck_id === id);
    if (r) setFocus({ nonce: Date.now(), bbox: bboxOf(r.path) });
  }, [idx, selectTruck]);

  // clicking a marker on the map selects the truck that serves it
  const onMapSelect = useCallback((s: Selection | null) => {
    if (!s || !plan) return;
    if (s.kind === 'area') {
      const tp = plan.truck_plans.find((t) => t.stops_detail.some((x) => x.location_id === s.id));
      if (tp) { setTab('trucks'); chooseTruck(tp.truck_id); }
    } else if (s.kind === 'depot') {
      const tp = plan.truck_plans.find((t) => t.warehouse_id === s.id);
      if (tp) { setTab('trucks'); chooseTruck(tp.truck_id); }
    }
  }, [plan, chooseTruck]);

  if (!state) return null;
  return (
    <div className="page dispatch">
      <aside className="dpanel">
        <PlanControls />
        {plan ? (
          <PlanBody plan={plan} tab={tab} setTab={setTab} selectedTruck={selectedTruck} chooseTruck={chooseTruck}
            explain={explain} setExplain={setExplain} focusArea={(lng, lat) => setFocus({ nonce: Date.now(), center: [lng, lat], zoom: 13.4 })} />
        ) : null}
      </aside>
      <div className="mapwrap">
        <DispatchMap plan={plan} idx={idx} selectedTruck={selectedTruck} explain={tab === 'explain' ? explain : null} focus={focus} onSelect={onMapSelect} />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------------------------- controls
function PlanControls() {
  const { state, plan, generatePlan, busy } = useStore();
  const [effort, setEffort] = useState<keyof typeof EFFORT>('standard');
  const flagged = state?.affected_areas.length ?? 0;
  const cap = Math.max(1, Math.min(60, flagged));
  const [areas, setAreas] = useState(36);
  const n = Math.min(areas, cap);
  const planning = busy === 'plan';
  if (!state) return null;
  const availableTrucks = state.trucks.filter((t) => t.status === 'Available').length;
  const activeDepots = state.warehouses.filter((w) => w.active).length;
  const stale = plan && plan.scenario_name !== state.scenario.name;
  const go = () => generatePlan({ generations: EFFORT[effort].generations, population_size: EFFORT[effort].population_size, max_areas: n });

  return (
    <section className="dpanel__sec">
      <div className="dpanel__head">
        <div>
          <h2>{plan ? 'Plan for these conditions' : 'Plan the relief runs'}</h2>
          <p className="muted">
            {flagged === 0 ? 'No area is flagged for relief right now.' : `${flagged} areas need relief · ${activeDepots} depots · ${availableTrucks} trucks`}
          </p>
        </div>
        {plan && (
          <button className="btn btn--primary" disabled={planning || flagged === 0} onClick={go}>
            {planning ? <><span className="spinner" style={{ borderTopColor: 'var(--on-accent)' }} />Planning…</> : 'Plan again'}
          </button>
        )}
      </div>
      {flagged === 0 && <p className="muted" style={{ marginTop: 8 }}>Pick a replay or drill from the top bar to try the planner.</p>}
      {stale && <div className="notice" style={{ marginTop: 12 }}><TriangleAlert size={16} /><div>This plan was made for “{plan!.scenario_name}”, not the conditions shown now. Plan again to update it.</div></div>}
      <details className="opts" open={!plan}>
        <summary>Plan settings</summary>
        <div className="field" style={{ margin: '10px 0 12px' }}>
          <span>Search effort</span>
          <div className="segmented" role="group" aria-label="Search effort">
            {(Object.keys(EFFORT) as (keyof typeof EFFORT)[]).map((k) => (
              <button key={k} aria-pressed={effort === k} onClick={() => setEffort(k)}>{EFFORT[k].label}</button>
            ))}
          </div>
        </div>
        <label className="field">
          <span>Areas to serve: the {n} most severe</span>
          <input type="range" min={Math.min(6, cap)} max={cap} value={n} onChange={(e) => setAreas(Number(e.target.value))} disabled={flagged === 0} />
        </label>
      </details>
      {!plan && (
        <button className="btn btn--primary btn--block" style={{ marginTop: 14 }} disabled={planning || flagged === 0} onClick={go}>
          {planning ? <><span className="spinner" style={{ borderTopColor: 'var(--on-accent)' }} />Planning routes…</> : 'Generate dispatch plan'}
        </button>
      )}
      {planning && <p className="muted" style={{ marginTop: 8, fontSize: 'var(--fs-sm)' }}>Finding the fastest roads and assigning trucks. Thorough searches can take a minute.</p>}
      <div style={{ marginTop: 12 }}><RoadDataNotice compact slim={!!plan} /></div>
    </section>
  );
}

// ---------------------------------------------------------------------------------------------- plan body
function PlanBody({ plan, tab, setTab, selectedTruck, chooseTruck, explain, setExplain, focusArea }: {
  plan: Plan; tab: Tab; setTab: (t: Tab) => void; selectedTruck: string | null; chooseTruck: (id: string | null) => void;
  explain: ExplainState | null; setExplain: (e: ExplainState | null) => void; focusArea: (lng: number, lat: number) => void;
}) {
  const [warnOpen, setWarnOpen] = useState(false);
  const last = addHours(plan.plan_start, plan.makespan_hours ?? plan.total_travel_time_hours);
  return (
    <>
      <section className="dpanel__sec dpanel__kpis">
        <div><b className="num">{fmt(plan.coverage_pct, 0)}%</b><span>relief delivered</span></div>
        <div><b className="num">{fmtClock(last)}</b><span>last delivery</span></div>
        <div><b className="num">{fmtPeople(plan.people_served ?? 0)}</b><span>people reached</span></div>
        <div><b className="num">{plan.truck_plans.length}</b><span>trucks used</span></div>
      </section>
      {plan.warnings.length > 0 && (
        <section className="dpanel__sec" style={{ paddingTop: 12, paddingBottom: 12 }}>
          <div className="notice">
            <TriangleAlert size={16} />
            <div>
              {warnOpen ? <ul className="why">{plan.warnings.map((w, i) => <li key={i}>{w}</li>)}</ul> : <span>{plan.warnings[0]}</span>}
              {plan.warnings.length > 1 && <button className="linkish" style={{ justifySelf: 'start' }} onClick={() => setWarnOpen((o) => !o)}>{warnOpen ? 'Show less' : `Show ${plan.warnings.length - 1} more`}</button>}
            </div>
          </div>
        </section>
      )}
      <div className="dpanel__tabs segmented" role="tablist">
        <button role="tab" aria-selected={tab === 'trucks'} onClick={() => setTab('trucks')}><TruckIcon size={14} style={{ verticalAlign: '-2px', marginRight: 6 }} />Trucks</button>
        <button role="tab" aria-selected={tab === 'deliveries'} onClick={() => setTab('deliveries')}><ListChecks size={14} style={{ verticalAlign: '-2px', marginRight: 6 }} />Delivery times</button>
        <button role="tab" aria-selected={tab === 'explain'} onClick={() => setTab('explain')}><Sparkles size={14} style={{ verticalAlign: '-2px', marginRight: 6 }} />Explain a route</button>
      </div>
      <div className="dpanel__body">
        {tab === 'trucks' && <TrucksTab plan={plan} selectedTruck={selectedTruck} chooseTruck={chooseTruck} />}
        {tab === 'deliveries' && <DeliveriesTab plan={plan} chooseTruck={(id) => { setTab('trucks'); chooseTruck(id); }} focusArea={focusArea} />}
        {tab === 'explain' && <ExplainTab plan={plan} explain={explain} setExplain={setExplain} selectedTruck={selectedTruck} />}
      </div>
    </>
  );
}

function TrucksTab({ plan, selectedTruck, chooseTruck }: { plan: Plan; selectedTruck: string | null; chooseTruck: (id: string | null) => void }) {
  const sorted = useMemo(() => [...plan.truck_plans].sort((a, b) => (a.stops_detail[0]?.eta_hours ?? 99) - (b.stops_detail[0]?.eta_hours ?? 99)), [plan]);
  const ref = useRef<HTMLLIElement | null>(null);
  useEffect(() => { ref.current?.scrollIntoView({ block: 'nearest' }); }, [selectedTruck]);
  return (
    <ul className="trucks">
      {sorted.map((t) => {
        const open = t.truck_id === selectedTruck;
        return (
          <li key={t.truck_id} ref={open ? ref : undefined} className={open ? 'is-open' : ''}>
            <button className="trow" aria-expanded={open} onClick={() => chooseTruck(open ? null : t.truck_id)}>
              <span className="trow__no">{t.truck_number}</span>
              <span className="trow__sub">{t.warehouse_name.replace(/\s*[-–]\s*.*$/, '')} · {t.stops_detail.length} stop{t.stops_detail.length === 1 ? '' : 's'}</span>
              <span className="trow__time num">{fmtClock(t.depart_clock)} to {fmtClock(t.return_clock)}</span>
              <span className="bar trow__load" title={`Carrying ${fmt(t.capacity_utilization_pct)}% of capacity`}><i style={{ width: `${Math.min(100, t.capacity_utilization_pct)}%` }} /></span>
            </button>
            {open && (
              <div className="trow__detail">
                <dl className="kv" style={{ marginBottom: 10 }}>
                  <dt>Distance</dt><dd>{fmt(t.distance_km, 1)} km</dd>
                  <dt>Time on the road</dt><dd>{fmtDuration(t.total_hours)}</dd>
                  <dt>Load</dt><dd>{fmt(t.total_load_units)} of {fmt(t.capacity_limit)} items</dd>
                  <dt>Fuel</dt><dd>{fmt(t.fuel_usage_liters, 1)} L</dd>
                </dl>
                <TruckTimeline plan={plan} truck={t} />
              </div>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function DeliveriesTab({ plan, chooseTruck, focusArea }: { plan: Plan; chooseTruck: (id: string) => void; focusArea: (lng: number, lat: number) => void }) {
  const { state } = useStore();
  const rows = useMemo(() => {
    const by = new Map<string, { id: string; name: string; sev: string; eta: number; trucks: string[]; truckIds: string[]; delivered: number; people: number }>();
    for (const t of plan.truck_plans) {
      for (const s of t.stops_detail) {
        const r = by.get(s.location_id) ?? { id: s.location_id, name: s.location_name, sev: s.severity, eta: s.eta_hours, trucks: [], truckIds: [], delivered: 0, people: s.people_affected };
        r.eta = Math.min(r.eta, s.eta_hours);
        r.trucks.push(t.truck_number);
        r.truckIds.push(t.truck_id);
        r.delivered += sumBundle(s.delivered);
        by.set(s.location_id, r);
      }
    }
    const served = [...by.values()].sort((a, b) => a.eta - b.eta);
    const missing = (state?.affected_areas ?? []).filter((a) => !by.has(a.id)).sort((a, b) => b.risk_score - a.risk_score);
    return { served, missing };
  }, [plan, state]);
  const areaById = useMemo(() => new Map((state?.affected_areas ?? []).map((a) => [a.id, a])), [state]);

  return (
    <div>
      <table className="dtable">
        <thead><tr><th>Area</th><th>Arrives</th><th>Truck</th></tr></thead>
        <tbody>
          {rows.served.map((r) => {
            const a = areaById.get(r.id);
            const need = a ? sumBundle(a.demands) : 0;
            return (
              <tr key={r.id} tabIndex={0} onClick={() => { chooseTruck(r.truckIds[0]); if (a) focusArea(a.lng, a.lat); }}
                onKeyDown={(e) => { if (e.key === 'Enter') chooseTruck(r.truckIds[0]); }}>
                <td><span className={`dot sev-${r.sev}`} style={{ display: 'inline-block', marginRight: 8 }} />{r.name}
                  {need > 0 && r.delivered < need * 0.98 && <small className="muted"> · gets {Math.round((100 * r.delivered) / need)}%</small>}</td>
                <td className="num"><b>{fmtClock(addHours(plan.plan_start, r.eta))}</b><small className="muted"> +{fmtDuration(r.eta)}</small></td>
                <td className="num">{r.trucks[0].replace('TN-RL-', '#')}{r.trucks.length > 1 ? ` +${r.trucks.length - 1}` : ''}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {rows.missing.length > 0 && (
        <>
          <h3 className="dpanel__sub">Not in this plan ({rows.missing.length})</h3>
          <p className="muted" style={{ fontSize: 'var(--fs-sm)', marginBottom: 6 }}>Plans cover the most severe areas first. Raise “Areas to serve” to include more.</p>
          <ul className="rows">{rows.missing.slice(0, 12).map((a) => <li key={a.id}><span className={`dot sev-${a.severity}`} /><span className="rows__name">{a.name}</span><span className="num muted">{fmt(a.people_affected)}</span></li>)}</ul>
        </>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------------------------- A* explainer
function ExplainTab({ plan, explain, setExplain, selectedTruck }: { plan: Plan; explain: ExplainState | null; setExplain: (e: ExplainState | null) => void; selectedTruck: string | null }) {
  const { state, toast } = useStore();
  const truck = plan.truck_plans.find((t) => t.truck_id === selectedTruck) ?? plan.truck_plans[0];
  const [from, setFrom] = useState(truck?.warehouse_id ?? '');
  const [to, setTo] = useState(truck?.stops_detail[0]?.location_id ?? '');
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    if (truck) { setFrom(truck.warehouse_id); setTo(truck.stops_detail[0]?.location_id ?? ''); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedTruck]);

  const run = async () => {
    if (!from || !to) return;
    setLoading(true);
    try {
      const r = await api.astar(from, to);
      setExplain({ result: r, upto: 0, playing: r.found });
    } catch (e) { toast(e instanceof Error ? e.message : 'Could not trace that route', 'error'); }
    finally { setLoading(false); }
  };

  // playback clock
  useEffect(() => {
    if (!explain?.playing) return;
    let raf = 0;
    let last = performance.now();
    const n = explain.result.trace.length;
    const perSec = Math.max(8, n / 7);
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      setExplain({ ...explain, upto: Math.min(n, explain.upto + perSec * dt), playing: explain.upto + perSec * dt < n });
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [explain, setExplain]);

  const r = explain?.result;
  const n = r?.trace.length ?? 0;
  const step = r && explain ? r.trace[Math.max(0, Math.min(n - 1, Math.floor(explain.upto) - 1))] : null;
  const done = !!explain && explain.upto >= n;
  const areaNames = state?.affected_areas ?? [];

  return (
    <div className="explain">
      <p className="muted" style={{ marginBottom: 12 }}>
        Watch how A* finds the fastest open road. It always checks the junction with the lowest <i>time so far + straight-line time to go</i>,
        so it heads toward the destination and detours around closed or slow roads.
      </p>
      <label className="field"><span>From depot</span>
        <select className="select" value={from} onChange={(e) => setFrom(e.target.value)}>
          {(state?.warehouses ?? []).map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}
        </select>
      </label>
      <label className="field" style={{ marginTop: 8 }}><span>To area</span>
        <select className="select" value={to} onChange={(e) => setTo(e.target.value)}>
          {areaNames.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
        </select>
      </label>
      <button className="btn btn--primary btn--block" style={{ marginTop: 12 }} onClick={run} disabled={loading || !from || !to}>
        {loading ? <span className="spinner" /> : <Sparkles size={16} />}Explain this route
      </button>

      {r && explain && (
        <div className="explain__out">
          {!r.found ? <div className="notice notice--error"><TriangleAlert size={16} /><div>{r.message}</div></div> : (
            <>
              <div className="explain__ctl">
                <button className="btn btn--sm btn--icon" aria-label={explain.playing ? 'Pause' : 'Play'}
                  onClick={() => setExplain({ ...explain, playing: !explain.playing, upto: done ? 0 : explain.upto })}>
                  {explain.playing ? <Pause size={15} /> : <Play size={15} />}
                </button>
                <button className="btn btn--sm btn--icon" aria-label="Restart" onClick={() => setExplain({ ...explain, upto: 0, playing: true })}><RotateCcw size={15} /></button>
                <input type="range" min={0} max={n} value={Math.floor(explain.upto)} aria-label="Step through the search"
                  onChange={(e) => setExplain({ ...explain, upto: Number(e.target.value), playing: false })} />
              </div>
              <p className="explain__step num">
                {done ? <b>{r.message}</b>
                  : step ? <>Step {Math.floor(explain.upto)} of {n}: checking a junction. Time so far <b>{fmtDuration(step[2])}</b> + straight-line estimate <b>{fmtDuration(step[3])}</b> = <b>{fmtDuration(step[2] + step[3])}</b>.
                    {' '}{fmt(step[4])} candidates waiting, {fmt(step[5])} already checked.</>
                    : 'Press play to start.'}
              </p>
              {done && (
                <dl className="kv" style={{ marginTop: 10 }}>
                  <dt>Fastest route</dt><dd>{fmt(r.total_distance_km, 1)} km, {fmtDuration(r.estimated_travel_time_hours)}</dd>
                  <dt>Junctions checked</dt><dd>{fmt(r.nodes_explored_count)} of {fmt(state?.network.nodes)}</dd>
                  <dt>Truck speed assumed</dt><dd>up to {fmt(r.vmax_kmh)} km/h</dd>
                </dl>
              )}
              <p className="muted" style={{ marginTop: 10, fontSize: 'var(--fs-xs)' }}>
                Dots are junctions A* checked: pale blue means a low total time estimate, dark blue means high. A and B on the map are the depot and the area.
              </p>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------------------------- map with time bar
function DispatchMap({ plan, idx, selectedTruck, explain, focus, onSelect }: {
  plan: Plan | null; idx: ReturnType<typeof indexPlan>; selectedTruck: string | null; explain: ExplainState | null; focus: CityMapFocus | null; onSelect: (s: Selection | null) => void;
}) {
  const { state } = useStore();
  const span = plan ? Math.max(plan.makespan_hours ?? plan.total_travel_time_hours, 0.05) : 1;
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [rate, setRate] = useState(15); // plan minutes per real second
  const planId = plan?.plan_id;
  useEffect(() => { setT(0); setPlaying(false); }, [planId]);

  useEffect(() => {
    if (!playing) return;
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      let finished = false;
      setT((cur) => {
        const nxt = cur + (rate / 60) * dt;
        if (nxt >= span) { finished = true; return span; }
        return nxt;
      });
      if (finished) setPlaying(false); else raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, rate, span]);

  const scene = useMemo<Partial<Scene>>(() => {
    if (explain) {
      const r = explain.result;
      const fs = r.trace.map((x) => x[2] + x[3]);
      return {
        explain: {
          trace: r.trace, upto: Math.floor(explain.upto), path: r.path_lnglat as LngLat[], start: [r.start[1], r.start[0]], goal: [r.goal[1], r.goal[0]],
          done: explain.upto >= r.trace.length, fMin: Math.min(...fs, 0), fMax: Math.max(...fs, 0.01),
        },
      };
    }
    const routes = idx.map((r) => ({ id: r.truck.truck_id, path: r.path, selected: r.truck.truck_id === selectedTruck, dim: false }));
    const trucks = idx.flatMap((r) => {
      const pos = truckPosition(r, t);
      return pos ? [{ id: r.truck.truck_id, label: r.truck.truck_number.replace('TN-RL-', '#'), pos, selected: r.truck.truck_id === selectedTruck }] : [];
    });
    const sel = idx.find((r) => r.truck.truck_id === selectedTruck);
    const areas = new Map((state?.affected_areas ?? []).map((a) => [a.id, a]));
    const stops = sel
      ? sel.truck.stops_detail.flatMap((s, i) => {
          const a = areas.get(s.location_id);
          return a ? [{ pos: [a.lng, a.lat] as LngLat, n: i + 1, severity: s.severity, label: fmtClock(addHours(plan?.plan_start, s.eta_hours)) }] : [];
        })
      : [];
    return { routes, trucks, stops };
  }, [idx, selectedTruck, t, explain, state, plan]);

  const clock = fmtClock(addHours(plan?.plan_start, t));
  const done = plan ? plan.truck_plans.reduce((s, tp) => s + tp.stops_detail.filter((x) => x.eta_hours <= t).length, 0) : 0;
  const totalStops = plan ? plan.truck_plans.reduce((s, tp) => s + tp.stops_detail.length, 0) : 0;
  const moving = idx.filter((r) => truckPosition(r, t) && t > 0 && t < r.truck.total_hours).length;

  return (
    <CityMap layers={DISPATCH_LAYERS} riskMode="faint" selection={null} onSelect={onSelect} scene={scene} focus={focus}
      padding={{ top: 70, bottom: 120, left: 40, right: 60 }}>
      {!plan && (
        <div className="mapnote"><b>Routes appear here</b><span>Generate a plan to see every truck’s route and when it reaches each area.</span></div>
      )}
      {plan && !explain && (
        <div className="timebar" role="group" aria-label="Plan playback">
          <button className="btn btn--primary btn--icon" onClick={() => { if (t >= span) setT(0); setPlaying((p) => !p); }} aria-label={playing ? 'Pause' : 'Play the plan'}>
            {playing ? <Pause size={16} /> : <Play size={16} />}
          </button>
          <div className="timebar__main">
            <input type="range" min={0} max={span} step={span / 400} value={t} aria-label="Time since dispatch"
              onChange={(e) => { setPlaying(false); setT(Number(e.target.value)); }} />
            <div className="timebar__ticks num"><span>{fmtClock(plan.plan_start)}</span><span>{fmtClock(addHours(plan.plan_start, span))}</span></div>
          </div>
          <div className="timebar__read">
            <b className="num">{clock}</b>
            <span className="num muted">{moving} on the road · {done} of {totalStops} deliveries made</span>
          </div>
          <select className="select timebar__rate" value={rate} onChange={(e) => setRate(Number(e.target.value))} aria-label="Playback speed">
            <option value={6}>Slow</option><option value={15}>Normal</option><option value={40}>Fast</option>
          </select>
        </div>
      )}
    </CityMap>
  );
}
