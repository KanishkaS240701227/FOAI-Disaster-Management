import { useCallback, useMemo, useState } from 'react';
import { Layers } from 'lucide-react';
import { api } from '../api';
import { useStore } from '../store';
import CityMap, { type CityMapFocus } from '../map/CityMap';
import Gauge from '../components/Gauge';
import Forecast from '../components/Forecast';
import Inspector from '../components/Inspector';
import RoadDataNotice from '../components/RoadDataNotice';
import type { LayerToggles, Selection } from '../types';
import { fmt, fmtPeople, scoreLevel } from '../lib/format';
import { geometryBBox } from '../lib/geo';

const LAYER_LABEL: [keyof LayerToggles, string][] = [
  ['risk', 'Risk by zone'], ['floods', 'Flood spots'], ['depots', 'Depots'], ['needs', 'Areas needing relief'], ['roads', 'Closed and slow roads'],
];

export default function MapPage() {
  const { state, zones, zoneName, toast } = useStore();
  const [layers, setLayers] = useState<LayerToggles>({ risk: true, floods: true, depots: true, needs: true, roads: true });
  const [layersOpen, setLayersOpen] = useState(() => typeof window === 'undefined' || window.matchMedia('(min-width: 981px)').matches);
  const [selection, setSelection] = useState<Selection | null>(null);
  const [focus, setFocus] = useState<CityMapFocus | null>(null);

  const ranked = useMemo(() => {
    if (!state || !zones) return [];
    return zones.features
      .map((f) => ({ id: String(f.properties.id), name: String(f.properties.name), kind: String(f.properties.kind), number: f.properties.number as number | null, score: state.hazard.zones[String(f.properties.id)] }))
      .filter((z) => z.score)
      .sort((a, b) => b.score.overall - a.score.overall);
  }, [state, zones]);

  const pickZone = useCallback((id: string) => {
    setSelection({ kind: 'zone', id });
    const f = zones?.features.find((x) => String(x.properties.id) === id);
    if (f) setFocus({ nonce: Date.now(), bbox: geometryBBox(f.geometry) });
  }, [zones]);

  const pickRoad = useCallback(async (lng: number, lat: number) => {
    try {
      const probe = await api.probeRoad(lat, lng);
      if (probe.found && (probe.distance_m ?? 0) < 400) setSelection({ kind: 'road', probe });
      else toast('No road found at that spot. Click closer to a road.');
    } catch (e) { toast(e instanceof Error ? e.message : 'Could not look up that road', 'error'); }
  }, [toast]);

  const reprobeRoad = useCallback(async () => {
    if (selection?.kind !== 'road' || !selection.probe.geometry) return;
    const g = selection.probe.geometry;
    const mid = g[Math.floor(g.length / 2)];
    try { setSelection({ kind: 'road', probe: await api.probeRoad(mid[1], mid[0]) }); } catch { setSelection(null); }
  }, [selection]);

  if (!state) return null;
  const sum = state.hazard.summary;
  const h = state.hazard.state;
  const total = ranked.length;
  const counts = state.network.state;
  const level = scoreLevel(sum.meter);
  const quake = h.quakes[0];

  const headline = sum.zones_high === 0
    ? 'No area is at High or Severe risk right now.'
    : `${sum.zones_high} of ${total} areas are at High or Severe risk. ${fmtPeople(sum.pop_at_risk)} people live there.`;

  return (
    <div className="page mappage">
      <aside className="ledger" aria-label="Risk summary">
        <section className="meter">
          <Gauge value={sum.meter} />
          <div className="meter__read">
            <p className="meter__label">Disaster meter</p>
            <div className="meter__num num" style={{ color: `var(--lvl-${level.toLowerCase()})` }}>{Math.round(sum.meter)}</div>
            <span className={`pill lvl-${sum.level}`}>{sum.level}</span>
            <p className="meter__line">{headline}</p>
            {sum.zones_high > 0 && <p className="muted meter__worst">Worst: <button className="linkish" onClick={() => pickZone(sum.peak_zone)}>{zoneName(sum.peak_zone)}</button></p>}
          </div>
        </section>

        <section className="ledger__sec">
          <h2>Conditions</h2>
          <dl className="conds">
            <div><dt>Rain, 24 hours</dt><dd className="num">{fmt(h.rain24)} <small>mm</small></dd></div>
            <div><dt>Rain, 72 hours</dt><dd className="num">{fmt(h.rain72)} <small>mm</small></dd></div>
            <div><dt>Wind gusts</dt><dd className="num">{fmt(h.gust_kmh)} <small>km/h</small></dd></div>
            <div><dt>Sea surge</dt><dd className="num">{fmt(h.surge_m, 1)} <small>m</small></dd></div>
            {h.river_index != null && <div><dt>River level</dt><dd className="num">{Math.round(h.river_index * 100)}<small>% of flood stage</small></dd></div>}
            <div><dt>Earthquakes</dt><dd className="num">{quake ? <>M{quake.mag.toFixed(1)} <small>{fmt(quake.dist_km)} km away</small></> : <small>None felt</small>}</dd></div>
          </dl>
        </section>

        <section className="ledger__sec ledger__sec--grow">
          <h2>All areas, highest risk first</h2>
          <ul className="zlist">
            {ranked.map((z) => {
              const sel = selection?.kind === 'zone' && selection.id === z.id;
              return (
                <li key={z.id}>
                  <button className="zrow" aria-pressed={sel} onClick={() => pickZone(z.id)}>
                    <span className={`zrow__chip lvl-${z.score.level}`} />
                    <span className="zrow__name">{z.name}<small>{z.kind === 'gcc' ? `Zone ${z.number}` : 'Suburb'}</small></span>
                    <span className="zrow__bar bar" style={{ ['--bar' as string]: `var(--lvl-${z.score.level.toLowerCase()})` }}><i style={{ width: `${Math.round(z.score.overall)}%` }} /></span>
                    <b className="num">{Math.round(z.score.overall)}</b>
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
        {state.network.source === 'fallback' && <section className="ledger__sec"><RoadDataNotice compact /></section>}
      </aside>

      <div className="mapwrap">
        <CityMap
          layers={layers}
          selection={selection}
          onSelect={setSelection}
          onRoadPick={pickRoad}
          focus={focus}
          padding={{ top: 70, bottom: 150, left: 40, right: selection ? 380 : 60 }}
        >
          <button className="layers-toggle maptool" aria-expanded={layersOpen} onClick={() => setLayersOpen((o) => !o)}>
            <Layers size={16} /><span>Layers</span>
          </button>
          <div className="layers" role="group" aria-label="Map layers" hidden={!layersOpen}>
            {LAYER_LABEL.map(([k, label]) => (
              <label key={k} className="switch">
                <input type="checkbox" checked={layers[k]} onChange={(e) => setLayers((l) => ({ ...l, [k]: e.target.checked }))} />
                <i />
                <span>{label}{k === 'roads' && (counts.blocked + counts.slow > 0) ? <em className="muted num"> {counts.blocked} closed, {counts.slow} slow</em> : null}</span>
              </label>
            ))}
            <div className="legend" aria-label="Risk colours">
              {(['Low', 'Elevated', 'High', 'Severe'] as const).map((l) => <span key={l}><i className={`lvl-${l}`} style={{ background: `var(--lvl-${l.toLowerCase()})` }} />{l}</span>)}
            </div>
          </div>
          <Forecast />
          {selection && <Inspector selection={selection} onClose={() => setSelection(null)} onRoadChanged={reprobeRoad} />}
        </CityMap>
      </div>
    </div>
  );
}
